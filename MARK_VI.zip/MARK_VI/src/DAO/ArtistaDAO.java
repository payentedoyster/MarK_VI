package DAO;

public interface ArtistaDAO {

}
