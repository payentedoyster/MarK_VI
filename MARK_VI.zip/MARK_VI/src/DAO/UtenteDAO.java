package DAO;

public interface UtenteDAO {

}
