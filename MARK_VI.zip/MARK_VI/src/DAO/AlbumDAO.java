package DAO;

public interface AlbumDAO {

}
