package DAO;

public interface TracciaDAO {

}
