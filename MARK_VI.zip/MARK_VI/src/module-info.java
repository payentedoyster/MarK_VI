module MARK_VI {
	requires java.sql;
	requires java.desktop;
}