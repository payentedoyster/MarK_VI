package Modelli;

public class Artista {

}
