package Modelli;

public class Utente {

}
