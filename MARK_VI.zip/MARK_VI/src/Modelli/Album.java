package Modelli;

public class Album {

}
