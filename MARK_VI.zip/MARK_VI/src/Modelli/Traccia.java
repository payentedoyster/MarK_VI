package Modelli;

public class Traccia {

}
